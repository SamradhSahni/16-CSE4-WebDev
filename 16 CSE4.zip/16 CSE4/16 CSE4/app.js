const express = require("express");
const app = express();
const path = require("path");
const mongoose = require("mongoose");
const methodOverride = require("method-override");
const flash = require("connect-flash");
const passport = require("passport");
const LocalStrategy = require("passport-local");
const User = require("./models/user");
const mongoSanitize = require("express-mongo-sanitize");
const nodemailer = require("nodemailer");
const session = require("express-session");
const MongoDBStore = require("connect-mongo");

// Replace this with your actual MongoDB Atlas connection string
const dbURL = "mongodb+srv://samradh123:Nhq6L6P5YsDff454@cluster1.xyguf.mongodb.net/?retryWrites=true&w=majority&appName=Cluster1";

// Server port
const PORT = 3000;

// MongoDB Connection
async function main() {
  try {
    await mongoose.connect(dbURL, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
      tlsAllowInvalidCertificates: true, // Only for development
    });
    console.log("Connected to MongoDB database");
  } catch (err) {
    console.error("Error connecting to MongoDB:", err);
  }
}
main();

// Express configuration
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));
app.use(express.static(path.join(__dirname, "public")));
app.use("/utilities", express.static(path.join(__dirname, "utilities")));

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(methodOverride("_method"));
app.use(mongoSanitize());

// Session Configuration
const secret = "thisismysecret"; // Use a secure random string in production
const store = MongoDBStore.create({
  mongoUrl: dbURL,
  touchAfter: 24 * 60 * 60, // Update once per day
  crypto: { secret },
});

store.on("error", (err) => {
  console.error("SESSION STORE ERROR", err);
});

app.use(
  session({
    store,
    name: "session",
    secret,
    resave: false,
    saveUninitialized: false,
    cookie: {
      httpOnly: true,
      secure: false, // Change to true in production (HTTPS)
      expires: new Date(Date.now() + 1000 * 60 * 60 * 24 * 7), // 7 days
    },
  })
);

// Passport Configuration
app.use(passport.initialize());
app.use(passport.session());
passport.use(new LocalStrategy({ usernameField: "email" }, User.authenticate()));
passport.serializeUser(User.serializeUser());
passport.deserializeUser(User.deserializeUser());

// Flash Messages Middleware
app.use(flash());
app.use((req, res, next) => {
  res.locals.loggedInUser = req.user;
  res.locals.success = req.flash("success");
  res.locals.error = req.flash("error");
  next();
});

// Routes
const listenRoutes = require("./routes/listenRoutes");
const budgetRoutes = require("./routes/budgetRoutes");
const notizenRoutes = require("./routes/notizenRoutes");
const kalenderRoutes = require("./routes/kalenderRoutes");
const projekteRoutes = require("./routes/projekteRoutes");
const userRoutes = require("./routes/userRoutes");

app.use("/listen", listenRoutes);
app.use("/budget", budgetRoutes);
app.use("/notizen", notizenRoutes);
app.use("/kalender", kalenderRoutes);
app.use("/projekte", projekteRoutes);
app.use("/", userRoutes);

// General Routes
app.get("/", (req, res) => {
  res.render("index");
});

app.get("/home", (req, res) => {
  if (!req.isAuthenticated()) {
    return res.redirect("/login");
  }
  res.render("pages/home", { user: req.user });
});

app.get("/kontakt", (req, res) => {
  res.render("pages/contact");
});

app.post("/kontakt", async (req, res) => {
  try {
    const { name, email, message } = req.body;

    // Configure Nodemailer
    const transporter = nodemailer.createTransport({
      host: "smtp.example.com", // Replace with your SMTP server
      port: 465,
      secure: true,
      auth: {
        user: "youremail@example.com", // Replace with your email
        pass: "yourpassword", // Replace with your email password
      },
    });

    // Email Options
    const mailOptions = {
      from: "youremail@example.com", // Replace with your email
      to: "youremail@example.com", // Replace with your email
      subject: `Message from ${name}`,
      text: `Message from ${email}:\n\n${message}`,
    };

    await transporter.sendMail(mailOptions);
    res.redirect("/nachricht-versendet");
  } catch (err) {
    console.error("Error sending email:", err);
    res.status(500).send("Failed to send your message.");
  }
});

// Error Handling
app.use((req, res) => {
  res.status(404).render("pages/404");
});

// Start Server
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
